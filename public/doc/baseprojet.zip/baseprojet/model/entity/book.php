<?php
// Classe représetant les livres stockés en base de données
class Livre {


}
