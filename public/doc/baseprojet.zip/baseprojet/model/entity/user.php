<?php
// Classe représetant les utilisateurs stockés en base de données
class Utilisateur {


}
