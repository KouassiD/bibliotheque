<?php
// Controleur qui gère l'affichage du détail d'un utilisateur
