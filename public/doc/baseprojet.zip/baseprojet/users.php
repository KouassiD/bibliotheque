<?php
// Controleur qui gère l'affichage de tous les utilisateurs
