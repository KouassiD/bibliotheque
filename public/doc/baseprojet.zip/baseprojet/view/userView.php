<p>l'utilisateur sur lequel on a cliqué s'affiche sur cette page</p>
