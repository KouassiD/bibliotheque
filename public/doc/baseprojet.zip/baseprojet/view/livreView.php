<p>Le livre sur lequel on a cliqué s'affiche ici/p>
